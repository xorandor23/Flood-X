<?php

$host = "localhost";
$username = "data_pengguna";
$password = "RV0yuXt4dLD!*um@";
$dbname = "data_saleplus";

// Create connection
$con = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}

?>