<?php

session_start();
require 'db.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $mode = $_POST['mode'];
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    
    if(isset($mode) and isset($user) and isset($pass)) {
        
        if ($mode === 'signup' and isset($_POST['name']) and isset($_POST['address'])) {

            $name = $_POST['name'];
            $address = $_POST['address'];
            
            $hashed = password_hash($pass, PASSWORD_DEFAULT);
            $query = $con->prepare("INSERT INTO customers (name, address, username, password) VALUES (?, ?, ?, ?)");    
            
            if (!$query) {
                die("SQL error: " . $con->error);
            }
            
            $query->bind_param("ssss", $name, $address, $user, $hashed);
            try {
                if ($query->execute()) {
                    header('Location: index.php?signup=1');
                    exit();
                }
            } catch (mysqli_sql_exception $e) {
                if ($e->getcode() === 1062) {
                    header('Location: signup.php?signerr=1');
                    exit();
                } else {
                    header("Location: signup.php?signerr=0&errmsg=$e");
                }
            }
            
            $query->close();
        
        } elseif ($mode === 'login') {
            
            $query = $con->prepare("SELECT password FROM customers WHERE username = ?");
            $query->bind_param("s", $user);
            $query->execute();
            $query->bind_result($hashed);

            if ($query->fetch() and password_verify($pass, $hashed)) {
                $_SESSION['logged_in'] = true;
                $_SESSION['user'] = $username;
                header('Location: dash/index.php');
                exit();
            } else {
                header('Location: index.php?signup=-1');
                exit();
            }
            
            $query->close();
        
        }
    } else {
        echo "Please fill all the form!";
    }

    $con->close();

}



?>